# Score Comparator – C Program

A simple beginner-level C program that compares the scores of two people.

## Features
- Takes names and scores from two users.
- Displays greetings.
- Compares scores and prints results.

## How to Run
```
make project1
./project1
```
